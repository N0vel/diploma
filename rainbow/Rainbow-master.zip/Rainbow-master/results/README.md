Contains plots of evaluation rewards and Q-values, plus saved model weights
